namespace SmartPOS.Domain.Common;

public interface ITenantEntity
{
    Guid TenantId { get; set; }
}
